// Plants vs Zombies 1 - Full Game Clone (PVZ Ultra Catsan)
// C++ SDL2 - 600x400 resolution
// Compile with clang:
//   clang++ PVZUltraCatsan.cpp -o PVZUltraCatsan -std=c++17 -lSDL2 -lSDL2_ttf -lSDL2_mixer
// If no SDL2_ttf: clang++ PVZUltraCatsan.cpp -o PVZUltraCatsan -std=c++17 -lSDL2 -DNO_TTF
// macOS Homebrew: add -I/opt/homebrew/include -L/opt/homebrew/lib (or /usr/local for Intel)

#include <SDL2/SDL.h>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>

// ============================================================
// CONSTANTS
// ============================================================
const int SCREEN_W = 600;
const int SCREEN_H = 400;
const int GRID_ROWS = 5;
const int GRID_COLS = 9;
const int CELL_W = 50;
const int CELL_H = 55;
const int GRID_X = 80;
const int GRID_Y = 80;
const int TOPBAR_H = 75;
const int FPS = 60;
const int FRAME_DELAY = 1000 / FPS;
const int MAX_LEVELS = 10;
const int SUN_VALUE = 50;
const int STARTING_SUN = 150;

// ============================================================
// ENUMS
// ============================================================
enum GameState {
    STATE_MENU,
    STATE_LEVEL_SELECT,
    STATE_PLAYING,
    STATE_PAUSED,
    STATE_GAME_OVER,
    STATE_LEVEL_COMPLETE,
    STATE_ALMANAC
};

enum PlantType {
    PLANT_NONE = 0,
    PLANT_PEASHOOTER,
    PLANT_SUNFLOWER,
    PLANT_WALLNUT,
    PLANT_SNOWPEA,
    PLANT_CHERRYBOMB,
    PLANT_REPEATER,
    PLANT_POTATOMINE,
    PLANT_CHOMPER,
    PLANT_COUNT
};

enum ZombieType {
    ZOMBIE_NORMAL = 0,
    ZOMBIE_CONE,
    ZOMBIE_BUCKET,
    ZOMBIE_FLAG,
    ZOMBIE_NEWSPAPER,
    ZOMBIE_POLE_VAULT,
    ZOMBIE_COUNT
};

// ============================================================
// COLOR HELPERS
// ============================================================
struct Color { Uint8 r, g, b, a; };
const Color COL_WHITE   = {255,255,255,255};
const Color COL_BLACK   = {0,0,0,255};
const Color COL_RED     = {220,50,50,255};
const Color COL_GREEN   = {50,180,50,255};
const Color COL_DGREEN  = {30,120,30,255};
const Color COL_BLUE    = {50,80,200,255};
const Color COL_YELLOW  = {255,220,50,255};
const Color COL_BROWN   = {139,90,43,255};
const Color COL_GRAY    = {140,140,140,255};
const Color COL_DGRAY   = {80,80,80,255};
const Color COL_LAWN    = {60,160,40,255};
const Color COL_LAWN2   = {70,175,50,255};
const Color COL_SKY     = {100,180,240,255};
const Color COL_ORANGE  = {240,150,30,255};
const Color COL_PINK    = {240,100,140,255};
const Color COL_PURPLE  = {140,60,180,255};
const Color COL_CYAN    = {80,200,220,255};
const Color COL_LBROWN  = {180,130,70,255};

void setColor(SDL_Renderer* r, Color c) { SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a); }

void fillRect(SDL_Renderer* r, int x, int y, int w, int h, Color c) {
    setColor(r, c);
    SDL_Rect rc = {x, y, w, h};
    SDL_RenderFillRect(r, &rc);
}

void drawRect(SDL_Renderer* r, int x, int y, int w, int h, Color c) {
    setColor(r, c);
    SDL_Rect rc = {x, y, w, h};
    SDL_RenderDrawRect(r, &rc);
}

void fillCircle(SDL_Renderer* r, int cx, int cy, int radius, Color c) {
    setColor(r, c);
    for (int y = -radius; y <= radius; y++) {
        int dx = (int)sqrt(radius * radius - y * y);
        SDL_RenderDrawLine(r, cx - dx, cy + y, cx + dx, cy + y);
    }
}

void drawLine(SDL_Renderer* r, int x1, int y1, int x2, int y2, Color c) {
    setColor(r, c);
    SDL_RenderDrawLine(r, x1, y1, x2, y2);
}

// ============================================================
// SIMPLE BITMAP FONT (no SDL_ttf needed)
// ============================================================
// 5x7 pixel font for basic ASCII 32-127
static const unsigned char FONT_5X7[][5] = {
    {0x00,0x00,0x00,0x00,0x00}, // 32 space
    {0x00,0x00,0x5F,0x00,0x00}, // 33 !
    {0x00,0x07,0x00,0x07,0x00}, // 34 "
    {0x14,0x7F,0x14,0x7F,0x14}, // 35 #
    {0x24,0x2A,0x7F,0x2A,0x12}, // 36 $
    {0x23,0x13,0x08,0x64,0x62}, // 37 %
    {0x36,0x49,0x55,0x22,0x50}, // 38 &
    {0x00,0x05,0x03,0x00,0x00}, // 39 '
    {0x00,0x1C,0x22,0x41,0x00}, // 40 (
    {0x00,0x41,0x22,0x1C,0x00}, // 41 )
    {0x08,0x2A,0x1C,0x2A,0x08}, // 42 *
    {0x08,0x08,0x3E,0x08,0x08}, // 43 +
    {0x00,0x50,0x30,0x00,0x00}, // 44 ,
    {0x08,0x08,0x08,0x08,0x08}, // 45 -
    {0x00,0x60,0x60,0x00,0x00}, // 46 .
    {0x20,0x10,0x08,0x04,0x02}, // 47 /
    {0x3E,0x51,0x49,0x45,0x3E}, // 48 0
    {0x00,0x42,0x7F,0x40,0x00}, // 49 1
    {0x42,0x61,0x51,0x49,0x46}, // 50 2
    {0x21,0x41,0x45,0x4B,0x31}, // 51 3
    {0x18,0x14,0x12,0x7F,0x10}, // 52 4
    {0x27,0x45,0x45,0x45,0x39}, // 53 5
    {0x3C,0x4A,0x49,0x49,0x30}, // 54 6
    {0x01,0x71,0x09,0x05,0x03}, // 55 7
    {0x36,0x49,0x49,0x49,0x36}, // 56 8
    {0x06,0x49,0x49,0x29,0x1E}, // 57 9
    {0x00,0x36,0x36,0x00,0x00}, // 58 :
    {0x00,0x56,0x36,0x00,0x00}, // 59 ;
    {0x00,0x08,0x14,0x22,0x41}, // 60 <
    {0x14,0x14,0x14,0x14,0x14}, // 61 =
    {0x41,0x22,0x14,0x08,0x00}, // 62 >
    {0x02,0x01,0x51,0x09,0x06}, // 63 ?
    {0x32,0x49,0x79,0x41,0x3E}, // 64 @
    {0x7E,0x11,0x11,0x11,0x7E}, // 65 A
    {0x7F,0x49,0x49,0x49,0x36}, // 66 B
    {0x3E,0x41,0x41,0x41,0x22}, // 67 C
    {0x7F,0x41,0x41,0x22,0x1C}, // 68 D
    {0x7F,0x49,0x49,0x49,0x41}, // 69 E
    {0x7F,0x09,0x09,0x01,0x01}, // 70 F
    {0x3E,0x41,0x41,0x51,0x32}, // 71 G
    {0x7F,0x08,0x08,0x08,0x7F}, // 72 H
    {0x00,0x41,0x7F,0x41,0x00}, // 73 I
    {0x20,0x40,0x41,0x3F,0x01}, // 74 J
    {0x7F,0x08,0x14,0x22,0x41}, // 75 K
    {0x7F,0x40,0x40,0x40,0x40}, // 76 L
    {0x7F,0x02,0x04,0x02,0x7F}, // 77 M
    {0x7F,0x04,0x08,0x10,0x7F}, // 78 N
    {0x3E,0x41,0x41,0x41,0x3E}, // 79 O
    {0x7F,0x09,0x09,0x09,0x06}, // 80 P
    {0x3E,0x41,0x51,0x21,0x5E}, // 81 Q
    {0x7F,0x09,0x19,0x29,0x46}, // 82 R
    {0x46,0x49,0x49,0x49,0x31}, // 83 S
    {0x01,0x01,0x7F,0x01,0x01}, // 84 T
    {0x3F,0x40,0x40,0x40,0x3F}, // 85 U
    {0x1F,0x20,0x40,0x20,0x1F}, // 86 V
    {0x7F,0x20,0x18,0x20,0x7F}, // 87 W
    {0x63,0x14,0x08,0x14,0x63}, // 88 X
    {0x03,0x04,0x78,0x04,0x03}, // 89 Y
    {0x61,0x51,0x49,0x45,0x43}, // 90 Z
    {0x00,0x00,0x7F,0x41,0x41}, // 91 [
    {0x02,0x04,0x08,0x10,0x20}, // 92 backslash
    {0x41,0x41,0x7F,0x00,0x00}, // 93 ]
    {0x04,0x02,0x01,0x02,0x04}, // 94 ^
    {0x40,0x40,0x40,0x40,0x40}, // 95 _
    {0x00,0x01,0x02,0x04,0x00}, // 96 `
    {0x20,0x54,0x54,0x54,0x78}, // 97 a
    {0x7F,0x48,0x44,0x44,0x38}, // 98 b
    {0x38,0x44,0x44,0x44,0x20}, // 99 c
    {0x38,0x44,0x44,0x48,0x7F}, // 100 d
    {0x38,0x54,0x54,0x54,0x18}, // 101 e
    {0x08,0x7E,0x09,0x01,0x02}, // 102 f
    {0x08,0x14,0x54,0x54,0x3C}, // 103 g
    {0x7F,0x08,0x04,0x04,0x78}, // 104 h
    {0x00,0x44,0x7D,0x40,0x00}, // 105 i
    {0x20,0x40,0x44,0x3D,0x00}, // 106 j
    {0x00,0x7F,0x10,0x28,0x44}, // 107 k
    {0x00,0x41,0x7F,0x40,0x00}, // 108 l
    {0x7C,0x04,0x18,0x04,0x78}, // 109 m
    {0x7C,0x08,0x04,0x04,0x78}, // 110 n
    {0x38,0x44,0x44,0x44,0x38}, // 111 o
    {0x7C,0x14,0x14,0x14,0x08}, // 112 p
    {0x08,0x14,0x14,0x18,0x7C}, // 113 q
    {0x7C,0x08,0x04,0x04,0x08}, // 114 r
    {0x48,0x54,0x54,0x54,0x20}, // 115 s
    {0x04,0x3F,0x44,0x40,0x20}, // 116 t
    {0x3C,0x40,0x40,0x20,0x7C}, // 117 u
    {0x1C,0x20,0x40,0x20,0x1C}, // 118 v
    {0x3C,0x40,0x30,0x40,0x3C}, // 119 w
    {0x44,0x28,0x10,0x28,0x44}, // 120 x
    {0x0C,0x50,0x50,0x50,0x3C}, // 121 y
    {0x44,0x64,0x54,0x4C,0x44}, // 122 z
    {0x00,0x08,0x36,0x41,0x00}, // 123 {
    {0x00,0x00,0x7F,0x00,0x00}, // 124 |
    {0x00,0x41,0x36,0x08,0x00}, // 125 }
    {0x08,0x08,0x2A,0x1C,0x08}, // 126 ~
};

void drawChar(SDL_Renderer* renderer, int x, int y, char ch, Color col, int scale = 1) {
    if (ch < 32 || ch > 126) return;
    const unsigned char* glyph = FONT_5X7[ch - 32];
    setColor(renderer, col);
    for (int col_idx = 0; col_idx < 5; col_idx++) {
        unsigned char line = glyph[col_idx];
        for (int row = 0; row < 7; row++) {
            if (line & (1 << row)) {
                if (scale == 1) {
                    SDL_RenderDrawPoint(renderer, x + col_idx, y + row);
                } else {
                    SDL_Rect rc = {x + col_idx * scale, y + row * scale, scale, scale};
                    SDL_RenderFillRect(renderer, &rc);
                }
            }
        }
    }
}

void drawText(SDL_Renderer* renderer, int x, int y, const char* text, Color col, int scale = 1) {
    int ox = x;
    while (*text) {
        if (*text == '\n') { y += 9 * scale; x = ox; }
        else { drawChar(renderer, x, y, *text, col, scale); x += 6 * scale; }
        text++;
    }
}

void drawTextCentered(SDL_Renderer* renderer, int cx, int cy, const char* text, Color col, int scale = 1) {
    int len = strlen(text);
    int w = len * 6 * scale;
    int h = 7 * scale;
    drawText(renderer, cx - w / 2, cy - h / 2, text, col, scale);
}

int textWidth(const char* text, int scale = 1) { return strlen(text) * 6 * scale; }

// ============================================================
// PLANT DATA
// ============================================================
struct PlantInfo {
    const char* name;
    int cost;
    int hp;
    int damage;
    int rechargeMs; // cooldown for seed packet
    int fireRateMs; // attack interval
    Color bodyColor;
    Color headColor;
};

PlantInfo plantData[PLANT_COUNT] = {
    {"None",        0,   0,  0,    0,    0, {0,0,0,0},{0,0,0,0}},
    {"Peashooter", 100, 100, 20, 5000, 1400, {50,160,50,255},{60,180,60,255}},
    {"Sunflower",   50, 100,  0, 5000, 5000, {50,160,50,255},{255,220,50,255}},
    {"Wall-nut",    50, 800,  0, 15000,   0, {180,130,60,255},{200,150,80,255}},
    {"Snow Pea",   175, 100, 20, 5000, 1400, {50,160,50,255},{100,200,240,255}},
    {"Cherry Bomb",150, 100,900, 25000,   0, {200,30,30,255},{240,50,50,255}},
    {"Repeater",   200, 100, 20, 5000, 1400, {50,160,50,255},{30,140,30,255}},
    {"Potato Mine", 25, 100,900, 20000,   0, {140,100,50,255},{100,70,30,255}},
    {"Chomper",    150, 100,999, 5000,30000, {50,160,50,255},{180,50,180,255}},
};

// ============================================================
// ZOMBIE DATA
// ============================================================
struct ZombieInfo {
    const char* name;
    int hp;
    float speed;    // pixels per frame
    int damage;
    int attackMs;
    Color bodyColor;
    Color headColor;
};

ZombieInfo zombieData[ZOMBIE_COUNT] = {
    {"Zombie",     200, 0.25f, 25, 500, {100,100,100,255},{140,180,100,255}},
    {"Cone",       560, 0.25f, 25, 500, {100,100,100,255},{240,160,40,255}},
    {"Bucket",     1300,0.22f, 25, 500, {100,100,100,255},{180,180,180,255}},
    {"Flag",       200, 0.35f, 25, 500, {100,100,100,255},{140,180,100,255}},
    {"Newspaper",  400, 0.25f, 25, 400, {100,100,100,255},{200,200,180,255}},
    {"Pole Vault", 340, 0.55f, 25, 500, {100,100,100,255},{140,180,100,255}},
};

// ============================================================
// GAME STRUCTS
// ============================================================
struct Plant {
    PlantType type;
    int row, col;
    int hp;
    Uint32 lastFire;
    Uint32 planted;
    bool armed; // for potato mine
    int chomping; // timer for chomper
};

struct Zombie {
    ZombieType type;
    int row;
    float x;
    int hp;
    int maxHp;
    float speed;
    Uint32 lastAttack;
    bool eating;
    bool slowed;
    Uint32 slowTimer;
    bool jumped; // pole vault
    bool isDead;
    int deathTimer;
};

struct Projectile {
    int row;
    float x, y;
    int damage;
    bool isIce;
    bool active;
};

struct Sun {
    float x, y;
    float targetY;
    bool falling;
    bool clicked;
    Uint32 spawnTime;
    bool fromFlower;
};

struct Particle {
    float x, y, vx, vy;
    int life;
    Color col;
};

struct LawnMower {
    int row;
    float x;
    bool active;
    bool triggered;
};

// ============================================================
// LEVEL DEFINITIONS
// ============================================================
struct WaveEntry {
    ZombieType type;
    int row; // -1 = random
    int delayMs;
};

struct LevelDef {
    const char* name;
    int numWaves;
    int zombiesPerWave;
    bool isNight;
    bool hasPool;
    PlantType availablePlants[PLANT_COUNT];
    int numPlants;
};

LevelDef levels[MAX_LEVELS] = {
    {"Day 1-1", 2, 3, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER}, 2},
    {"Day 1-2", 3, 4, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT}, 3},
    {"Day 1-3", 3, 5, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA}, 4},
    {"Day 1-4", 4, 5, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA, PLANT_CHERRYBOMB}, 5},
    {"Day 1-5", 4, 7, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA, PLANT_CHERRYBOMB, PLANT_REPEATER}, 6},
    {"Day 2-1", 5, 6, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA, PLANT_REPEATER, PLANT_POTATOMINE}, 6},
    {"Day 2-2", 5, 7, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA, PLANT_REPEATER, PLANT_POTATOMINE, PLANT_CHOMPER}, 7},
    {"Day 2-3", 6, 8, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA, PLANT_CHERRYBOMB, PLANT_REPEATER, PLANT_POTATOMINE, PLANT_CHOMPER}, 8},
    {"Day 2-4", 6, 9, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA, PLANT_CHERRYBOMB, PLANT_REPEATER, PLANT_POTATOMINE, PLANT_CHOMPER}, 8},
    {"Day 2-5", 7,10, false, false, {PLANT_PEASHOOTER, PLANT_SUNFLOWER, PLANT_WALLNUT, PLANT_SNOWPEA, PLANT_CHERRYBOMB, PLANT_REPEATER, PLANT_POTATOMINE, PLANT_CHOMPER}, 8},
};

// ============================================================
// DRAWING FUNCTIONS - PLANTS
// ============================================================
void drawPlantAt(SDL_Renderer* r, PlantType type, int px, int py, int w, int h, Uint32 tick) {
    int cx = px + w/2;
    int cy = py + h/2;
    float bob = sin(tick * 0.003f) * 2.0f;
    
    switch (type) {
    case PLANT_PEASHOOTER: {
        // Stem
        fillRect(r, cx-3, cy, 6, h/2-2, COL_GREEN);
        // Head
        fillCircle(r, cx, cy-2 + (int)bob, 14, {60,180,60,255});
        // Eye
        fillCircle(r, cx+4, cy-6 + (int)bob, 4, COL_WHITE);
        fillCircle(r, cx+5, cy-6 + (int)bob, 2, COL_BLACK);
        // Mouth (tube)
        fillRect(r, cx+8, cy-2 + (int)bob, 10, 6, {40,140,40,255});
    } break;
    case PLANT_SUNFLOWER: {
        fillRect(r, cx-3, cy+5, 6, h/2-8, COL_GREEN);
        // Petals
        for (int i = 0; i < 8; i++) {
            float a = i * 3.14159f / 4.0f + tick * 0.001f;
            int px2 = cx + (int)(cos(a) * 12);
            int py2 = cy - 4 + (int)(sin(a) * 12) + (int)bob;
            fillCircle(r, px2, py2, 5, COL_YELLOW);
        }
        // Center
        fillCircle(r, cx, cy - 4 + (int)bob, 8, {180,120,30,255});
        // Eyes
        fillCircle(r, cx-3, cy-6 + (int)bob, 2, COL_BLACK);
        fillCircle(r, cx+3, cy-6 + (int)bob, 2, COL_BLACK);
    } break;
    case PLANT_WALLNUT: {
        fillCircle(r, cx, cy + (int)(bob*0.3f), 18, {200,150,80,255});
        fillCircle(r, cx, cy + (int)(bob*0.3f), 15, {180,130,60,255});
        // Face
        fillCircle(r, cx-5, cy-4, 2, COL_BLACK);
        fillCircle(r, cx+5, cy-4, 2, COL_BLACK);
        // Mouth
        drawLine(r, cx-4, cy+4, cx+4, cy+4, COL_BLACK);
    } break;
    case PLANT_SNOWPEA: {
        fillRect(r, cx-3, cy, 6, h/2-2, COL_GREEN);
        fillCircle(r, cx, cy-2 + (int)bob, 14, COL_CYAN);
        fillCircle(r, cx+4, cy-6 + (int)bob, 4, COL_WHITE);
        fillCircle(r, cx+5, cy-6 + (int)bob, 2, {50,50,150,255});
        fillRect(r, cx+8, cy-2 + (int)bob, 10, 6, {60,160,200,255});
    } break;
    case PLANT_CHERRYBOMB: {
        float pulse = sin(tick * 0.01f) * 3.0f;
        fillCircle(r, cx-6, cy+2, 12 + (int)pulse, COL_RED);
        fillCircle(r, cx+6, cy+2, 12 + (int)pulse, COL_RED);
        // Angry eyes
        fillCircle(r, cx-8, cy-2, 3, COL_WHITE);
        fillCircle(r, cx-7, cy-2, 1, COL_BLACK);
        fillCircle(r, cx+4, cy-2, 3, COL_WHITE);
        fillCircle(r, cx+5, cy-2, 1, COL_BLACK);
        // Fuse
        drawLine(r, cx, cy-10, cx+3, cy-18, COL_BROWN);
        fillCircle(r, cx+3, cy-18, 3, COL_ORANGE);
    } break;
    case PLANT_REPEATER: {
        fillRect(r, cx-3, cy, 6, h/2-2, COL_GREEN);
        fillCircle(r, cx, cy-2 + (int)bob, 14, COL_DGREEN);
        fillCircle(r, cx+4, cy-6 + (int)bob, 4, COL_WHITE);
        fillCircle(r, cx+5, cy-6 + (int)bob, 2, COL_BLACK);
        // Double barrel
        fillRect(r, cx+8, cy-5 + (int)bob, 12, 4, {30,110,30,255});
        fillRect(r, cx+8, cy+1 + (int)bob, 12, 4, {30,110,30,255});
    } break;
    case PLANT_POTATOMINE: {
        fillCircle(r, cx, cy+6, 14, COL_BROWN);
        fillCircle(r, cx, cy+4, 10, COL_LBROWN);
        fillCircle(r, cx-3, cy+1, 3, COL_WHITE);
        fillCircle(r, cx-2, cy+1, 1, COL_BLACK);
        fillCircle(r, cx+3, cy+1, 3, COL_WHITE);
        fillCircle(r, cx+4, cy+1, 1, COL_BLACK);
    } break;
    case PLANT_CHOMPER: {
        fillRect(r, cx-3, cy+5, 6, h/2-8, COL_GREEN);
        // Head
        fillCircle(r, cx, cy-2 + (int)bob, 16, COL_PURPLE);
        // Mouth open
        fillRect(r, cx-12, cy-2 + (int)bob, 24, 10, {120,40,140,255});
        // Teeth
        for (int i = 0; i < 5; i++) {
            fillRect(r, cx-10 + i*5, cy-2 + (int)bob, 3, 4, COL_WHITE);
        }
        fillCircle(r, cx-4, cy-8 + (int)bob, 3, COL_WHITE);
        fillCircle(r, cx-3, cy-8 + (int)bob, 1, COL_BLACK);
    } break;
    default: break;
    }
}

// ============================================================
// DRAWING FUNCTIONS - ZOMBIES
// ============================================================
void drawZombieAt(SDL_Renderer* r, ZombieType type, float zx, int zy, int h, Uint32 tick, bool slowed, float hpRatio) {
    int cx = (int)zx;
    int cy = zy + h/2;
    float walk = sin(tick * 0.005f) * 3.0f;
    
    Color shirt = {100,100,100,255};
    Color skin = {140,180,100,255};
    if (slowed) { shirt = {100,100,160,255}; skin = {120,160,180,255}; }
    
    // Legs
    fillRect(r, cx-6, cy+8+(int)walk, 5, 14, {80,80,80,255});
    fillRect(r, cx+1, cy+8-(int)walk, 5, 14, {80,80,80,255});
    // Body
    fillRect(r, cx-8, cy-8, 16, 20, shirt);
    // Arms
    int armAngle = (int)(sin(tick*0.004f) * 8);
    fillRect(r, cx-14, cy-6+armAngle, 8, 5, skin);
    fillRect(r, cx+6, cy-6-armAngle, 8, 5, skin);
    // Head
    fillCircle(r, cx, cy-16, 10, skin);
    // Eyes
    fillCircle(r, cx-3, cy-18, 2, COL_RED);
    fillCircle(r, cx+3, cy-18, 2, COL_RED);
    
    // Type-specific
    switch (type) {
    case ZOMBIE_CONE:
        // Cone on head
        for (int i = 0; i < 12; i++) {
            int w = 10 - i * 6 / 12;
            fillRect(r, cx - w, cy - 28 + i, w * 2, 1, COL_ORANGE);
        }
        break;
    case ZOMBIE_BUCKET:
        fillRect(r, cx-9, cy-28, 18, 14, COL_GRAY);
        drawRect(r, cx-9, cy-28, 18, 14, COL_DGRAY);
        break;
    case ZOMBIE_FLAG:
        drawLine(r, cx+10, cy-28, cx+10, cy-8, COL_BROWN);
        fillRect(r, cx+10, cy-28, 14, 8, COL_RED);
        break;
    case ZOMBIE_NEWSPAPER:
        fillRect(r, cx+8, cy-14, 10, 16, {220,220,200,255});
        break;
    case ZOMBIE_POLE_VAULT:
        drawLine(r, cx+10, cy-30, cx+14, cy+10, COL_BROWN);
        break;
    default: break;
    }
    
    // HP bar
    if (hpRatio < 1.0f) {
        fillRect(r, cx-12, cy-32, 24, 3, COL_RED);
        fillRect(r, cx-12, cy-32, (int)(24*hpRatio), 3, COL_GREEN);
    }
}

// ============================================================
// BUTTON HELPER
// ============================================================
struct Button {
    int x, y, w, h;
    const char* label;
    Color bg, fg;
    bool contains(int mx, int my) const { return mx>=x && mx<x+w && my>=y && my<y+h; }
};

void drawButton(SDL_Renderer* r, const Button& btn, bool hover = false) {
    Color bg = btn.bg;
    if (hover) { bg.r = std::min(255, bg.r + 30); bg.g = std::min(255, bg.g + 30); bg.b = std::min(255, bg.b + 30); }
    fillRect(r, btn.x, btn.y, btn.w, btn.h, bg);
    drawRect(r, btn.x, btn.y, btn.w, btn.h, COL_WHITE);
    drawTextCentered(r, btn.x + btn.w/2, btn.y + btn.h/2, btn.label, btn.fg, 2);
}

// ============================================================
// MAIN GAME CLASS
// ============================================================
class Game {
public:
    SDL_Window* window;
    SDL_Renderer* renderer;
    bool running;
    GameState state;
    Uint32 tick;
    int mouseX, mouseY;
    bool mouseDown;
    bool mouseClicked;
    
    // Progress
    int highestLevel; // 0-based, unlocked up to this
    int currentLevel;
    
    // Game state
    int sunCount;
    PlantType selectedPlant;
    int selectedSlot;
    Plant grid[GRID_ROWS][GRID_COLS];
    std::vector<Zombie> zombies;
    std::vector<Projectile> projectiles;
    std::vector<Sun> suns;
    std::vector<Particle> particles;
    LawnMower mowers[GRID_ROWS];
    
    // Seed packets
    PlantType seedSlots[8];
    int numSeeds;
    Uint32 seedCooldowns[8];
    
    // Wave management
    int currentWave;
    int totalWaves;
    int zombiesSpawned;
    int zombiesThisWave;
    Uint32 nextSpawnTime;
    Uint32 waveStartTime;
    bool finalWave;
    bool allSpawned;
    
    // Timers
    Uint32 lastSunDrop;
    Uint32 gameStartTime;
    
    // Shovel mode
    bool shovelMode;
    
    // Menu animation
    float menuZombieX;
    
    Game() : window(nullptr), renderer(nullptr), running(true), state(STATE_MENU),
             tick(0), mouseX(0), mouseY(0), mouseDown(false), mouseClicked(false),
             highestLevel(0), currentLevel(0), sunCount(STARTING_SUN),
             selectedPlant(PLANT_NONE), selectedSlot(-1), shovelMode(false), menuZombieX(620.0f) {}
    
    bool init() {
        if (SDL_Init(SDL_INIT_VIDEO) < 0) {
            printf("SDL init failed: %s\n", SDL_GetError());
            return false;
        }
        window = SDL_CreateWindow("Plants vs Zombies", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                   SCREEN_W, SCREEN_H, SDL_WINDOW_SHOWN);
        if (!window) return false;
        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
        if (!renderer) return false;
        srand((unsigned)time(nullptr));
        return true;
    }
    
    void cleanup() {
        if (renderer) SDL_DestroyRenderer(renderer);
        if (window) SDL_DestroyWindow(window);
        SDL_Quit();
    }
    
    // --------------------------------------------------------
    // MAIN MENU
    // --------------------------------------------------------
    void drawMenu() {
        // Sky gradient
        for (int y = 0; y < SCREEN_H; y++) {
            float t = (float)y / SCREEN_H;
            Uint8 r = (Uint8)(40 + t * 30);
            Uint8 g = (Uint8)(100 + t * 60);
            Uint8 b = (Uint8)(200 - t * 40);
            SDL_SetRenderDrawColor(renderer, r, g, b, 255);
            SDL_RenderDrawLine(renderer, 0, y, SCREEN_W, y);
        }
        
        // Ground
        fillRect(renderer, 0, SCREEN_H - 80, SCREEN_W, 80, COL_LAWN);
        fillRect(renderer, 0, SCREEN_H - 82, SCREEN_W, 4, COL_DGREEN);
        
        // Decorative flowers
        for (int i = 0; i < 8; i++) {
            int fx = 30 + i * 75;
            int fy = SCREEN_H - 60 + (int)(sin(tick*0.003f + i) * 3);
            fillRect(renderer, fx, fy, 3, 20, COL_GREEN);
            fillCircle(renderer, fx+1, fy-4, 6, COL_YELLOW);
            fillCircle(renderer, fx+1, fy-4, 3, {180,120,30,255});
        }
        
        // Zombie walking across
        menuZombieX -= 0.3f;
        if (menuZombieX < -40) menuZombieX = 640;
        drawZombieAt(renderer, ZOMBIE_NORMAL, menuZombieX, SCREEN_H - 120, 50, tick, false, 1.0f);
        if (menuZombieX > 200)
            drawZombieAt(renderer, ZOMBIE_CONE, menuZombieX - 180, SCREEN_H - 120, 50, tick + 500, false, 1.0f);
        
        // Title with shadow
        float titleBob = sin(tick * 0.002f) * 4;
        drawTextCentered(renderer, SCREEN_W/2+2, 52 + (int)titleBob + 2, "PLANTS vs ZOMBIES", COL_BLACK, 3);
        drawTextCentered(renderer, SCREEN_W/2, 50 + (int)titleBob, "PLANTS vs ZOMBIES", COL_WHITE, 3);
        
        // Subtitle
        drawTextCentered(renderer, SCREEN_W/2, 90 + (int)titleBob, "SDL2 Edition", COL_YELLOW, 1);
        
        // Buttons
        Button playBtn = {SCREEN_W/2-80, 140, 160, 45, "PLAY", COL_GREEN, COL_WHITE};
        Button almanacBtn = {SCREEN_W/2-80, 200, 160, 35, "ALMANAC", {80,60,140,255}, COL_WHITE};
        Button quitBtn = {SCREEN_W/2-80, 250, 160, 35, "QUIT", COL_RED, COL_WHITE};
        
        drawButton(renderer, playBtn, playBtn.contains(mouseX, mouseY));
        drawButton(renderer, almanacBtn, almanacBtn.contains(mouseX, mouseY));
        drawButton(renderer, quitBtn, quitBtn.contains(mouseX, mouseY));
        
        // Version
        drawText(renderer, 4, SCREEN_H - 12, "v1.0 - C++ SDL2", COL_DGRAY, 1);
        
        if (mouseClicked) {
            if (playBtn.contains(mouseX, mouseY)) state = STATE_LEVEL_SELECT;
            else if (almanacBtn.contains(mouseX, mouseY)) state = STATE_ALMANAC;
            else if (quitBtn.contains(mouseX, mouseY)) running = false;
        }
    }
    
    // --------------------------------------------------------
    // ALMANAC
    // --------------------------------------------------------
    void drawAlmanac() {
        fillRect(renderer, 0, 0, SCREEN_W, SCREEN_H, {30,20,10,255});
        drawTextCentered(renderer, SCREEN_W/2, 15, "ALMANAC", COL_YELLOW, 3);
        
        // Plants
        drawText(renderer, 20, 50, "PLANTS:", COL_GREEN, 2);
        for (int i = 1; i < PLANT_COUNT; i++) {
            int x = 20 + ((i-1) % 4) * 145;
            int y = 80 + ((i-1) / 4) * 80;
            fillRect(renderer, x, y, 130, 70, {50,40,20,255});
            drawRect(renderer, x, y, 130, 70, COL_GREEN);
            drawPlantAt(renderer, (PlantType)i, x+5, y+10, 40, 50, tick);
            drawText(renderer, x+48, y+8, plantData[i].name, COL_WHITE, 1);
            char buf[64];
            snprintf(buf, sizeof(buf), "Cost: %d", plantData[i].cost);
            drawText(renderer, x+48, y+20, buf, COL_YELLOW, 1);
            snprintf(buf, sizeof(buf), "HP: %d", plantData[i].hp);
            drawText(renderer, x+48, y+30, buf, COL_CYAN, 1);
            if (plantData[i].damage > 0) {
                snprintf(buf, sizeof(buf), "DMG: %d", plantData[i].damage);
                drawText(renderer, x+48, y+40, buf, COL_RED, 1);
            }
        }
        
        // Zombies
        drawText(renderer, 20, 250, "ZOMBIES:", COL_RED, 2);
        for (int i = 0; i < ZOMBIE_COUNT; i++) {
            int x = 20 + i * 95;
            int y = 275;
            fillRect(renderer, x, y, 85, 70, {50,40,20,255});
            drawRect(renderer, x, y, 85, 70, COL_RED);
            drawZombieAt(renderer, (ZombieType)i, x+25, y+5, 50, tick, false, 1.0f);
            drawText(renderer, x+5, y+56, zombieData[i].name, COL_WHITE, 1);
        }
        
        // Back
        Button backBtn = {SCREEN_W/2-50, SCREEN_H-30, 100, 25, "BACK", COL_DGRAY, COL_WHITE};
        drawButton(renderer, backBtn, backBtn.contains(mouseX, mouseY));
        if (mouseClicked && backBtn.contains(mouseX, mouseY)) state = STATE_MENU;
    }
    
    // --------------------------------------------------------
    // LEVEL SELECT
    // --------------------------------------------------------
    void drawLevelSelect() {
        // Background
        for (int y = 0; y < SCREEN_H; y++) {
            float t = (float)y / SCREEN_H;
            SDL_SetRenderDrawColor(renderer, (Uint8)(20+t*20), (Uint8)(40+t*30), (Uint8)(15+t*15), 255);
            SDL_RenderDrawLine(renderer, 0, y, SCREEN_W, y);
        }
        
        drawTextCentered(renderer, SCREEN_W/2, 25, "SELECT LEVEL", COL_YELLOW, 3);
        
        // Path
        for (int i = 0; i < MAX_LEVELS - 1; i++) {
            int x1 = 80 + (i % 5) * 100;
            int y1 = 100 + (i / 5) * 130;
            int x2 = 80 + ((i+1) % 5) * 100;
            int y2 = 100 + ((i+1) / 5) * 130;
            Color pathCol = (i < highestLevel) ? COL_GREEN : COL_DGRAY;
            drawLine(renderer, x1, y1, x2, y2, pathCol);
        }
        
        for (int i = 0; i < MAX_LEVELS; i++) {
            int bx = 80 + (i % 5) * 100 - 30;
            int by = 100 + (i / 5) * 130 - 25;
            bool unlocked = (i <= highestLevel);
            bool hover = (mouseX >= bx && mouseX < bx+60 && mouseY >= by && mouseY < by+50);
            
            Color bg = unlocked ? (Color){50,130,50,255} : (Color){60,60,60,255};
            if (hover && unlocked) { bg.r += 30; bg.g += 30; bg.b += 30; }
            
            fillRect(renderer, bx, by, 60, 50, bg);
            drawRect(renderer, bx, by, 60, 50, unlocked ? COL_GREEN : COL_DGRAY);
            
            char buf[32];
            snprintf(buf, sizeof(buf), "%s", levels[i].name);
            drawTextCentered(renderer, bx+30, by+18, buf, unlocked ? COL_WHITE : COL_DGRAY, 1);
            
            if (!unlocked) {
                drawTextCentered(renderer, bx+30, by+34, "LOCKED", COL_RED, 1);
            }
            
            // Stars for completed levels
            if (i < highestLevel) {
                for (int s = 0; s < 3; s++) {
                    fillCircle(renderer, bx + 15 + s*15, by + 42, 4, COL_YELLOW);
                }
            }
            
            if (mouseClicked && hover && unlocked) {
                currentLevel = i;
                startLevel(i);
            }
        }
        
        // Back button
        Button backBtn = {10, SCREEN_H-40, 80, 30, "BACK", COL_DGRAY, COL_WHITE};
        drawButton(renderer, backBtn, backBtn.contains(mouseX, mouseY));
        if (mouseClicked && backBtn.contains(mouseX, mouseY)) state = STATE_MENU;
    }
    
    // --------------------------------------------------------
    // START LEVEL
    // --------------------------------------------------------
    void startLevel(int lvl) {
        state = STATE_PLAYING;
        sunCount = STARTING_SUN;
        selectedPlant = PLANT_NONE;
        selectedSlot = -1;
        shovelMode = false;
        
        // Clear grid
        for (int r = 0; r < GRID_ROWS; r++)
            for (int c = 0; c < GRID_COLS; c++)
                grid[r][c] = {PLANT_NONE, r, c, 0, 0, false, 0};
        
        zombies.clear();
        projectiles.clear();
        suns.clear();
        particles.clear();
        
        // Setup seeds
        numSeeds = levels[lvl].numPlants;
        for (int i = 0; i < numSeeds; i++) {
            seedSlots[i] = levels[lvl].availablePlants[i];
            seedCooldowns[i] = 0;
        }
        
        // Lawn mowers
        for (int r = 0; r < GRID_ROWS; r++) {
            mowers[r] = {r, (float)(GRID_X - 30), true, false};
        }
        
        // Wave setup
        currentWave = 0;
        totalWaves = levels[lvl].numWaves;
        zombiesSpawned = 0;
        zombiesThisWave = levels[lvl].zombiesPerWave;
        finalWave = false;
        allSpawned = false;
        
        gameStartTime = SDL_GetTicks();
        lastSunDrop = gameStartTime;
        nextSpawnTime = gameStartTime + 15000; // first wave at 15s
        waveStartTime = nextSpawnTime;
    }
    
    // --------------------------------------------------------
    // SPAWN ZOMBIE
    // --------------------------------------------------------
    void spawnZombie(int wave) {
        int row = rand() % GRID_ROWS;
        ZombieType zt = ZOMBIE_NORMAL;
        
        // Harder zombies in later waves/levels
        int difficulty = currentLevel * 2 + wave;
        int roll = rand() % 100;
        
        if (wave == totalWaves - 1) {
            // Final wave - flag zombie first
            if (zombiesSpawned == 0) zt = ZOMBIE_FLAG;
            else if (roll < 20 && difficulty > 3) zt = ZOMBIE_BUCKET;
            else if (roll < 45 && difficulty > 1) zt = ZOMBIE_CONE;
            else if (roll < 55 && difficulty > 5) zt = ZOMBIE_POLE_VAULT;
            else if (roll < 65 && difficulty > 4) zt = ZOMBIE_NEWSPAPER;
        } else {
            if (roll < 10 && difficulty > 4) zt = ZOMBIE_BUCKET;
            else if (roll < 30 && difficulty > 1) zt = ZOMBIE_CONE;
            else if (roll < 38 && difficulty > 5) zt = ZOMBIE_POLE_VAULT;
            else if (roll < 45 && difficulty > 3) zt = ZOMBIE_NEWSPAPER;
        }
        
        Zombie z;
        z.type = zt;
        z.row = row;
        z.x = SCREEN_W + 20 + (rand() % 40);
        z.hp = zombieData[zt].hp;
        z.maxHp = z.hp;
        z.speed = zombieData[zt].speed;
        z.lastAttack = SDL_GetTicks();
        z.eating = false;
        z.slowed = false;
        z.slowTimer = 0;
        z.jumped = false;
        z.isDead = false;
        z.deathTimer = 0;
        
        zombies.push_back(z);
        zombiesSpawned++;
    }
    
    // --------------------------------------------------------
    // GAME UPDATE
    // --------------------------------------------------------
    void updateGame() {
        Uint32 now = SDL_GetTicks();
        
        // -- Sun drops from sky --
        if (now - lastSunDrop > 7000) {
            Sun s;
            s.x = GRID_X + rand() % (GRID_COLS * CELL_W);
            s.y = -20;
            s.targetY = GRID_Y + rand() % (GRID_ROWS * CELL_H);
            s.falling = true;
            s.clicked = false;
            s.spawnTime = now;
            s.fromFlower = false;
            suns.push_back(s);
            lastSunDrop = now;
        }
        
        // -- Update suns --
        for (auto& s : suns) {
            if (s.falling) {
                s.y += 0.5f;
                if (s.y >= s.targetY) { s.falling = false; s.spawnTime = now; }
            }
        }
        // Remove old suns
        suns.erase(std::remove_if(suns.begin(), suns.end(), [&](Sun& s) {
            return s.clicked || (!s.falling && now - s.spawnTime > 8000);
        }), suns.end());
        
        // -- Plant actions --
        for (int r = 0; r < GRID_ROWS; r++) {
            for (int c = 0; c < GRID_COLS; c++) {
                Plant& p = grid[r][c];
                if (p.type == PLANT_NONE) continue;
                
                // Sunflower produces sun
                if (p.type == PLANT_SUNFLOWER && now - p.lastFire > (Uint32)plantData[PLANT_SUNFLOWER].fireRateMs) {
                    Sun s;
                    int px = GRID_X + c * CELL_W + CELL_W/2;
                    int py = GRID_Y + r * CELL_H + CELL_H/2;
                    s.x = px - 10 + rand()%20;
                    s.y = py;
                    s.targetY = py + 20 + rand()%20;
                    s.falling = true;
                    s.clicked = false;
                    s.spawnTime = now;
                    s.fromFlower = true;
                    suns.push_back(s);
                    p.lastFire = now;
                }
                
                // Peashooter / Snow Pea / Repeater - shoot if zombie in row
                if ((p.type == PLANT_PEASHOOTER || p.type == PLANT_SNOWPEA || p.type == PLANT_REPEATER) 
                    && now - p.lastFire > (Uint32)plantData[p.type].fireRateMs) {
                    // Check if zombie in this row ahead
                    bool zombieAhead = false;
                    for (auto& z : zombies) {
                        if (!z.isDead && z.row == r && z.x > GRID_X + c * CELL_W) {
                            zombieAhead = true;
                            break;
                        }
                    }
                    if (zombieAhead) {
                        Projectile proj;
                        proj.row = r;
                        proj.x = GRID_X + c * CELL_W + CELL_W;
                        proj.y = GRID_Y + r * CELL_H + CELL_H/2;
                        proj.damage = plantData[p.type].damage;
                        proj.isIce = (p.type == PLANT_SNOWPEA);
                        proj.active = true;
                        projectiles.push_back(proj);
                        
                        // Repeater fires second pea
                        if (p.type == PLANT_REPEATER) {
                            Projectile proj2 = proj;
                            proj2.x -= 12;
                            projectiles.push_back(proj2);
                        }
                        p.lastFire = now;
                    }
                }
                
                // Potato mine arming
                if (p.type == PLANT_POTATOMINE && !p.armed && now - p.planted > 14000) {
                    p.armed = true;
                }
                
                // Potato mine explosion
                if (p.type == PLANT_POTATOMINE && p.armed) {
                    for (auto& z : zombies) {
                        if (!z.isDead && z.row == r) {
                            float zLeft = z.x - 15;
                            float cellRight = GRID_X + (c+1) * CELL_W;
                            float cellLeft = GRID_X + c * CELL_W;
                            if (zLeft < cellRight && z.x > cellLeft) {
                                // BOOM
                                z.hp -= 900;
                                p.type = PLANT_NONE;
                                addExplosion(GRID_X + c*CELL_W + CELL_W/2, GRID_Y + r*CELL_H + CELL_H/2, 30, COL_ORANGE);
                                break;
                            }
                        }
                    }
                }
                
                // Chomper
                if (p.type == PLANT_CHOMPER) {
                    if (p.chomping > 0) {
                        p.chomping--;
                    } else {
                        for (auto& z : zombies) {
                            if (!z.isDead && z.row == r) {
                                float cellCenter = GRID_X + c * CELL_W + CELL_W/2;
                                if (fabs(z.x - cellCenter) < CELL_W) {
                                    z.hp -= 999;
                                    p.chomping = (int)(30000.0f / FRAME_DELAY);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // -- Cherry bomb (instant) is handled on plant --
        
        // -- Update projectiles --
        for (auto& p : projectiles) {
            if (!p.active) continue;
            p.x += 3.0f;
            if (p.x > SCREEN_W + 10) { p.active = false; continue; }
            
            // Check zombie hit
            for (auto& z : zombies) {
                if (z.isDead || z.row != p.row) continue;
                if (fabs(p.x - z.x) < 15) {
                    z.hp -= p.damage;
                    if (p.isIce) {
                        z.slowed = true;
                        z.slowTimer = now;
                    }
                    p.active = false;
                    addExplosion((int)p.x, (int)p.y, 5, p.isIce ? COL_CYAN : COL_GREEN);
                    break;
                }
            }
        }
        projectiles.erase(std::remove_if(projectiles.begin(), projectiles.end(),
            [](Projectile& p){ return !p.active; }), projectiles.end());
        
        // -- Spawn zombies --
        if (!allSpawned && now >= nextSpawnTime) {
            if (currentWave < totalWaves) {
                spawnZombie(currentWave);
                
                if (zombiesSpawned >= zombiesThisWave) {
                    currentWave++;
                    zombiesSpawned = 0;
                    if (currentWave >= totalWaves) {
                        allSpawned = true;
                        finalWave = true;
                    } else {
                        int waveDelay = 18000 - currentLevel * 800;
                        if (waveDelay < 8000) waveDelay = 8000;
                        nextSpawnTime = now + waveDelay;
                        waveStartTime = nextSpawnTime;
                    }
                } else {
                    nextSpawnTime = now + 1500 + rand() % 2000;
                }
            }
        }
        
        // -- Update zombies --
        for (auto& z : zombies) {
            if (z.isDead) {
                z.deathTimer--;
                continue;
            }
            
            // Slow effect wears off
            if (z.slowed && now - z.slowTimer > 5000) z.slowed = false;
            
            float spd = z.speed;
            if (z.slowed) spd *= 0.5f;
            
            // Check if eating a plant
            z.eating = false;
            int zCol = (int)((z.x - GRID_X) / CELL_W);
            if (zCol >= 0 && zCol < GRID_COLS && grid[z.row][zCol].type != PLANT_NONE) {
                float cellCenter = GRID_X + zCol * CELL_W + CELL_W/2;
                if (fabs(z.x - cellCenter) < CELL_W/2 + 5) {
                    z.eating = true;
                    // Attack plant
                    if (now - z.lastAttack > (Uint32)zombieData[z.type].attackMs) {
                        grid[z.row][zCol].hp -= zombieData[z.type].damage;
                        z.lastAttack = now;
                        if (grid[z.row][zCol].hp <= 0) {
                            grid[z.row][zCol].type = PLANT_NONE;
                        }
                    }
                }
            }
            
            if (!z.eating) {
                z.x -= spd;
            }
            
            // Check if zombie reached left side
            if (z.x < GRID_X - 20) {
                // Lawn mower
                if (mowers[z.row].active && !mowers[z.row].triggered) {
                    mowers[z.row].triggered = true;
                } else if (!mowers[z.row].active || mowers[z.row].triggered) {
                    if (z.x < 0) {
                        state = STATE_GAME_OVER;
                        return;
                    }
                }
            }
            
            // Check dead
            if (z.hp <= 0) {
                z.isDead = true;
                z.deathTimer = 30;
                addExplosion((int)z.x, GRID_Y + z.row * CELL_H + CELL_H/2, 10, COL_GRAY);
            }
        }
        
        // Update lawn mowers
        for (int r = 0; r < GRID_ROWS; r++) {
            if (mowers[r].triggered) {
                mowers[r].x += 4.0f;
                // Kill zombies in path
                for (auto& z : zombies) {
                    if (!z.isDead && z.row == r && fabs(z.x - mowers[r].x) < 25) {
                        z.hp = 0;
                        z.isDead = true;
                        z.deathTimer = 20;
                    }
                }
                if (mowers[r].x > SCREEN_W + 30) {
                    mowers[r].active = false;
                }
            }
        }
        
        // Remove dead zombies after timer
        zombies.erase(std::remove_if(zombies.begin(), zombies.end(),
            [](Zombie& z){ return z.isDead && z.deathTimer <= 0; }), zombies.end());
        
        // -- Update particles --
        for (auto& pt : particles) {
            pt.x += pt.vx;
            pt.y += pt.vy;
            pt.vy += 0.1f;
            pt.life--;
        }
        particles.erase(std::remove_if(particles.begin(), particles.end(),
            [](Particle& p){ return p.life <= 0; }), particles.end());
        
        // -- Check level complete --
        if (allSpawned && zombies.empty()) {
            state = STATE_LEVEL_COMPLETE;
            if (currentLevel >= highestLevel && highestLevel < MAX_LEVELS - 1) {
                highestLevel = currentLevel + 1;
            }
        }
    }
    
    void addExplosion(int x, int y, int count, Color col) {
        for (int i = 0; i < count; i++) {
            Particle pt;
            pt.x = x;
            pt.y = y;
            pt.vx = (rand() % 40 - 20) / 10.0f;
            pt.vy = -(rand() % 30) / 10.0f;
            pt.life = 20 + rand() % 20;
            pt.col = col;
            particles.push_back(pt);
        }
    }
    
    // --------------------------------------------------------
    // HANDLE GAME INPUT
    // --------------------------------------------------------
    void handleGameInput() {
        if (!mouseClicked) return;
        Uint32 now = SDL_GetTicks();
        
        // Check sun click
        for (auto& s : suns) {
            if (!s.clicked && fabs(mouseX - s.x) < 20 && fabs(mouseY - s.y) < 20) {
                s.clicked = true;
                sunCount += SUN_VALUE;
                break;
            }
        }
        
        // Check seed packet click (top bar)
        for (int i = 0; i < numSeeds; i++) {
            int sx = 80 + i * 55;
            int sy = 5;
            if (mouseX >= sx && mouseX < sx + 50 && mouseY >= sy && mouseY < sy + 65) {
                PlantType pt = seedSlots[i];
                if (sunCount >= plantData[pt].cost && now >= seedCooldowns[i]) {
                    if (selectedSlot == i) {
                        selectedSlot = -1;
                        selectedPlant = PLANT_NONE;
                    } else {
                        selectedSlot = i;
                        selectedPlant = pt;
                        shovelMode = false;
                    }
                }
                return;
            }
        }
        
        // Shovel button
        int shovelX = 80 + numSeeds * 55 + 5;
        if (mouseX >= shovelX && mouseX < shovelX + 40 && mouseY >= 10 && mouseY < 60) {
            shovelMode = !shovelMode;
            if (shovelMode) { selectedPlant = PLANT_NONE; selectedSlot = -1; }
            return;
        }
        
        // Check grid click
        if (mouseY >= GRID_Y && mouseY < GRID_Y + GRID_ROWS * CELL_H &&
            mouseX >= GRID_X && mouseX < GRID_X + GRID_COLS * CELL_W) {
            int col = (mouseX - GRID_X) / CELL_W;
            int row = (mouseY - GRID_Y) / CELL_H;
            if (row >= 0 && row < GRID_ROWS && col >= 0 && col < GRID_COLS) {
                if (shovelMode) {
                    if (grid[row][col].type != PLANT_NONE) {
                        grid[row][col].type = PLANT_NONE;
                        shovelMode = false;
                    }
                } else if (selectedPlant != PLANT_NONE && grid[row][col].type == PLANT_NONE) {
                    // Plant it!
                    grid[row][col].type = selectedPlant;
                    grid[row][col].hp = plantData[selectedPlant].hp;
                    grid[row][col].lastFire = now;
                    grid[row][col].planted = now;
                    grid[row][col].armed = false;
                    grid[row][col].chomping = 0;
                    
                    sunCount -= plantData[selectedPlant].cost;
                    seedCooldowns[selectedSlot] = now + plantData[selectedPlant].rechargeMs;
                    
                    // Cherry bomb instant explosion
                    if (selectedPlant == PLANT_CHERRYBOMB) {
                        int cx = GRID_X + col * CELL_W + CELL_W/2;
                        int cy = GRID_Y + row * CELL_H + CELL_H/2;
                        for (auto& z : zombies) {
                            if (!z.isDead) {
                                float dx = z.x - cx;
                                float dy = (GRID_Y + z.row * CELL_H + CELL_H/2) - cy;
                                if (dx*dx + dy*dy < 120*120) {
                                    z.hp -= 900;
                                }
                            }
                        }
                        addExplosion(cx, cy, 60, COL_RED);
                        addExplosion(cx, cy, 40, COL_ORANGE);
                        addExplosion(cx, cy, 30, COL_YELLOW);
                        grid[row][col].type = PLANT_NONE;
                    }
                    
                    selectedPlant = PLANT_NONE;
                    selectedSlot = -1;
                }
            }
        }
    }
    
    // --------------------------------------------------------
    // DRAW GAME
    // --------------------------------------------------------
    void drawGame() {
        Uint32 now = SDL_GetTicks();
        
        // Sky
        for (int y = 0; y < TOPBAR_H; y++) {
            float t = (float)y / TOPBAR_H;
            SDL_SetRenderDrawColor(renderer, (Uint8)(70+t*30), (Uint8)(140+t*20), (Uint8)(220-t*30), 255);
            SDL_RenderDrawLine(renderer, 0, y, SCREEN_W, y);
        }
        
        // Lawn
        for (int r = 0; r < GRID_ROWS; r++) {
            for (int c = 0; c < GRID_COLS; c++) {
                int x = GRID_X + c * CELL_W;
                int y = GRID_Y + r * CELL_H;
                Color lc = ((r + c) % 2 == 0) ? COL_LAWN : COL_LAWN2;
                fillRect(renderer, x, y, CELL_W, CELL_H, lc);
                drawRect(renderer, x, y, CELL_W, CELL_H, {
                    static_cast<Uint8>(lc.r > 15 ? lc.r - 15 : 0),
                    static_cast<Uint8>(lc.g > 15 ? lc.g - 15 : 0),
                    static_cast<Uint8>(lc.b > 15 ? lc.b - 15 : 0),
                    static_cast<Uint8>(100)
                });
            }
        }
        
        // Side areas
        fillRect(renderer, 0, TOPBAR_H, GRID_X, SCREEN_H - TOPBAR_H, {80,50,30,255});
        fillRect(renderer, GRID_X + GRID_COLS*CELL_W, TOPBAR_H, SCREEN_W, SCREEN_H - TOPBAR_H, {50,80,40,255});
        fillRect(renderer, 0, GRID_Y + GRID_ROWS * CELL_H, SCREEN_W, SCREEN_H - GRID_Y - GRID_ROWS*CELL_H, {60,40,20,255});
        
        // Lawn mowers
        for (int r = 0; r < GRID_ROWS; r++) {
            if (mowers[r].active) {
                int mx = (int)mowers[r].x;
                int my = GRID_Y + r * CELL_H + CELL_H/2;
                fillRect(renderer, mx-10, my-8, 20, 16, COL_DGRAY);
                fillRect(renderer, mx-12, my-4, 24, 8, COL_RED);
                fillCircle(renderer, mx-8, my+8, 4, COL_BLACK);
                fillCircle(renderer, mx+8, my+8, 4, COL_BLACK);
            }
        }
        
        // Plants
        for (int r = 0; r < GRID_ROWS; r++) {
            for (int c = 0; c < GRID_COLS; c++) {
                if (grid[r][c].type != PLANT_NONE) {
                    int x = GRID_X + c * CELL_W;
                    int y = GRID_Y + r * CELL_H;
                    drawPlantAt(renderer, grid[r][c].type, x, y, CELL_W, CELL_H, tick);
                    
                    // HP bar for damaged plants
                    float ratio = (float)grid[r][c].hp / plantData[grid[r][c].type].hp;
                    if (ratio < 1.0f) {
                        fillRect(renderer, x+2, y+CELL_H-4, CELL_W-4, 3, COL_RED);
                        fillRect(renderer, x+2, y+CELL_H-4, (int)((CELL_W-4)*ratio), 3, COL_GREEN);
                    }
                    
                    // Potato mine not armed indicator
                    if (grid[r][c].type == PLANT_POTATOMINE && !grid[r][c].armed) {
                        drawTextCentered(renderer, x+CELL_W/2, y+CELL_H-8, "zzz", COL_GRAY, 1);
                    }
                    // Chomper digesting indicator
                    if (grid[r][c].type == PLANT_CHOMPER && grid[r][c].chomping > 0) {
                        drawTextCentered(renderer, x+CELL_W/2, y+CELL_H-8, "...", COL_PURPLE, 1);
                    }
                }
            }
        }
        
        // Plant placement preview
        if (selectedPlant != PLANT_NONE && mouseY >= GRID_Y && mouseX >= GRID_X) {
            int pc = (mouseX - GRID_X) / CELL_W;
            int pr = (mouseY - GRID_Y) / CELL_H;
            if (pr >= 0 && pr < GRID_ROWS && pc >= 0 && pc < GRID_COLS && grid[pr][pc].type == PLANT_NONE) {
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                SDL_SetRenderDrawColor(renderer, 255, 255, 255, 60);
                SDL_Rect previewRC = {GRID_X + pc*CELL_W, GRID_Y + pr*CELL_H, CELL_W, CELL_H};
                SDL_RenderFillRect(renderer, &previewRC);
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_NONE);
                drawPlantAt(renderer, selectedPlant, GRID_X + pc*CELL_W, GRID_Y + pr*CELL_H, CELL_W, CELL_H, tick);
            }
        }
        
        // Projectiles
        for (auto& p : projectiles) {
            if (p.active) {
                Color pc = p.isIce ? COL_CYAN : COL_GREEN;
                fillCircle(renderer, (int)p.x, (int)p.y, 4, pc);
                fillCircle(renderer, (int)p.x, (int)p.y, 2, COL_WHITE);
            }
        }
        
        // Zombies
        for (auto& z : zombies) {
            if (z.isDead) continue;
            float hpRatio = (float)z.hp / z.maxHp;
            drawZombieAt(renderer, z.type, z.x, GRID_Y + z.row * CELL_H - 5, CELL_H, tick, z.slowed, hpRatio);
        }
        
        // Suns
        for (auto& s : suns) {
            if (!s.clicked) {
                float pulse = sin(tick * 0.008f) * 2;
                fillCircle(renderer, (int)s.x, (int)s.y, 12 + (int)pulse, COL_YELLOW);
                fillCircle(renderer, (int)s.x, (int)s.y, 8 + (int)pulse, {255,240,100,255});
                // Rays
                for (int i = 0; i < 6; i++) {
                    float a = i * 3.14159f / 3.0f + tick * 0.005f;
                    int rx = (int)s.x + (int)(cos(a) * (16+pulse));
                    int ry = (int)s.y + (int)(sin(a) * (16+pulse));
                    drawLine(renderer, (int)s.x, (int)s.y, rx, ry, COL_YELLOW);
                }
            }
        }
        
        // Particles
        for (auto& pt : particles) {
            fillCircle(renderer, (int)pt.x, (int)pt.y, 2, pt.col);
        }
        
        // === TOP BAR ===
        fillRect(renderer, 0, 0, SCREEN_W, TOPBAR_H, {50,30,15,255});
        drawLine(renderer, 0, TOPBAR_H-1, SCREEN_W, TOPBAR_H-1, COL_BROWN);
        
        // Sun counter
        fillCircle(renderer, 30, 22, 14, COL_YELLOW);
        fillCircle(renderer, 30, 22, 10, {255,240,100,255});
        char sunBuf[32];
        snprintf(sunBuf, sizeof(sunBuf), "%d", sunCount);
        drawText(renderer, 48, 16, sunBuf, COL_WHITE, 2);
        
        // Seed packets
        for (int i = 0; i < numSeeds; i++) {
            int sx = 80 + i * 55;
            int sy = 5;
            PlantType pt = seedSlots[i];
            bool canAfford = sunCount >= plantData[pt].cost;
            bool cooledDown = now >= seedCooldowns[i];
            bool available = canAfford && cooledDown;
            
            Color bgCol = available ? (Color){60,40,20,255} : (Color){40,30,15,255};
            if (selectedSlot == i) bgCol = {80,60,30,255};
            
            fillRect(renderer, sx, sy, 50, 65, bgCol);
            drawRect(renderer, sx, sy, 50, 65, selectedSlot == i ? COL_YELLOW : COL_BROWN);
            
            // Mini plant icon
            drawPlantAt(renderer, pt, sx+5, sy+5, 40, 35, tick);
            
            // Cost
            char costBuf[16];
            snprintf(costBuf, sizeof(costBuf), "%d", plantData[pt].cost);
            Color costCol = canAfford ? COL_YELLOW : COL_RED;
            drawTextCentered(renderer, sx+25, sy+52, costBuf, costCol, 1);
            
            // Cooldown overlay
            if (!cooledDown) {
                float cdRatio = (float)(seedCooldowns[i] - now) / plantData[pt].rechargeMs;
                int cdH = (int)(65 * cdRatio);
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 140);
                SDL_Rect cdRect = {sx, sy, 50, cdH};
                SDL_RenderFillRect(renderer, &cdRect);
                SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_NONE);
            }
        }
        
        // Shovel
        int shovelX = 80 + numSeeds * 55 + 5;
        fillRect(renderer, shovelX, 10, 40, 50, shovelMode ? (Color){120,80,40,255} : (Color){80,60,30,255});
        drawRect(renderer, shovelX, 10, 40, 50, shovelMode ? COL_YELLOW : COL_BROWN);
        // Draw shovel icon
        fillRect(renderer, shovelX+17, 15, 6, 25, COL_BROWN);
        fillRect(renderer, shovelX+10, 38, 20, 8, COL_GRAY);
        drawTextCentered(renderer, shovelX+20, 52, "DIG", COL_WHITE, 1);
        
        // Wave indicator
        char waveBuf[64];
        if (!allSpawned) {
            snprintf(waveBuf, sizeof(waveBuf), "Wave %d/%d", currentWave + 1, totalWaves);
        } else {
            snprintf(waveBuf, sizeof(waveBuf), "FINAL WAVE!");
        }
        drawText(renderer, SCREEN_W - 110, 55, waveBuf, COL_RED, 1);
        
        // Level name
        drawText(renderer, SCREEN_W - 110, 8, levels[currentLevel].name, COL_WHITE, 2);
        
        // Pause hint
        drawText(renderer, SCREEN_W - 90, 68, "ESC=Pause", COL_GRAY, 1);
        
        // Shovel mode cursor
        if (shovelMode) {
            drawText(renderer, mouseX + 10, mouseY - 10, "DIG", COL_YELLOW, 1);
        }
    }
    
    // --------------------------------------------------------
    // DRAW PAUSED
    // --------------------------------------------------------
    void drawPaused() {
        drawGame();
        // Overlay
        SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 150);
        SDL_Rect overlay = {0, 0, SCREEN_W, SCREEN_H};
        SDL_RenderFillRect(renderer, &overlay);
        SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_NONE);
        
        drawTextCentered(renderer, SCREEN_W/2, SCREEN_H/2 - 50, "PAUSED", COL_WHITE, 3);
        
        Button resumeBtn = {SCREEN_W/2-70, SCREEN_H/2, 140, 35, "RESUME", COL_GREEN, COL_WHITE};
        Button menuBtn   = {SCREEN_W/2-70, SCREEN_H/2+45, 140, 35, "MENU", COL_RED, COL_WHITE};
        drawButton(renderer, resumeBtn, resumeBtn.contains(mouseX, mouseY));
        drawButton(renderer, menuBtn, menuBtn.contains(mouseX, mouseY));
        
        if (mouseClicked) {
            if (resumeBtn.contains(mouseX, mouseY)) state = STATE_PLAYING;
            else if (menuBtn.contains(mouseX, mouseY)) state = STATE_MENU;
        }
    }
    
    // --------------------------------------------------------
    // DRAW GAME OVER
    // --------------------------------------------------------
    void drawGameOver() {
        fillRect(renderer, 0, 0, SCREEN_W, SCREEN_H, COL_BLACK);
        
        // Zombie horde
        for (int i = 0; i < 8; i++) {
            float zx = 50 + i * 70 + sin(tick*0.003f + i)*10;
            drawZombieAt(renderer, (ZombieType)(i % ZOMBIE_COUNT), zx, SCREEN_H/2+20, 50, tick, false, 1.0f);
        }
        
        drawTextCentered(renderer, SCREEN_W/2, 60, "THE ZOMBIES ATE", COL_RED, 3);
        drawTextCentered(renderer, SCREEN_W/2, 100, "YOUR BRAINS!", COL_RED, 3);
        
        Button retryBtn = {SCREEN_W/2-70, SCREEN_H/2-30, 140, 35, "RETRY", COL_GREEN, COL_WHITE};
        Button menuBtn  = {SCREEN_W/2-70, SCREEN_H/2+15, 140, 35, "MENU", COL_RED, COL_WHITE};
        drawButton(renderer, retryBtn, retryBtn.contains(mouseX, mouseY));
        drawButton(renderer, menuBtn, menuBtn.contains(mouseX, mouseY));
        
        if (mouseClicked) {
            if (retryBtn.contains(mouseX, mouseY)) startLevel(currentLevel);
            else if (menuBtn.contains(mouseX, mouseY)) state = STATE_MENU;
        }
    }
    
    // --------------------------------------------------------
    // DRAW LEVEL COMPLETE
    // --------------------------------------------------------
    void drawLevelComplete() {
        // Green victory background
        for (int y = 0; y < SCREEN_H; y++) {
            float t = (float)y / SCREEN_H;
            SDL_SetRenderDrawColor(renderer, (Uint8)(20+t*20), (Uint8)(60+t*40), (Uint8)(20+t*20), 255);
            SDL_RenderDrawLine(renderer, 0, y, SCREEN_W, y);
        }
        
        // Celebration particles
        if (tick % 5 == 0) {
            addExplosion(rand() % SCREEN_W, rand() % (SCREEN_H/2), 3, 
                (Color){(Uint8)(rand()%256),(Uint8)(rand()%256),(Uint8)(rand()%256),255});
        }
        for (auto& pt : particles) {
            pt.x += pt.vx; pt.y += pt.vy; pt.vy += 0.05f; pt.life--;
            fillCircle(renderer, (int)pt.x, (int)pt.y, 3, pt.col);
        }
        particles.erase(std::remove_if(particles.begin(), particles.end(),
            [](Particle& p){ return p.life <= 0; }), particles.end());
        
        float bob = sin(tick * 0.003f) * 5;
        drawTextCentered(renderer, SCREEN_W/2, 60 + (int)bob, "LEVEL COMPLETE!", COL_YELLOW, 3);
        
        char buf[64];
        snprintf(buf, sizeof(buf), "%s cleared!", levels[currentLevel].name);
        drawTextCentered(renderer, SCREEN_W/2, 110, buf, COL_WHITE, 2);
        
        // Stars
        for (int i = 0; i < 3; i++) {
            float starBob = sin(tick*0.004f + i*1.0f) * 5;
            fillCircle(renderer, SCREEN_W/2 - 40 + i * 40, 150 + (int)starBob, 12, COL_YELLOW);
            fillCircle(renderer, SCREEN_W/2 - 40 + i * 40, 150 + (int)starBob, 8, {255,240,100,255});
        }
        
        bool hasNext = (currentLevel < MAX_LEVELS - 1);
        if (hasNext) {
            Button nextBtn = {SCREEN_W/2-70, 200, 140, 35, "NEXT LEVEL", COL_GREEN, COL_WHITE};
            drawButton(renderer, nextBtn, nextBtn.contains(mouseX, mouseY));
            if (mouseClicked && nextBtn.contains(mouseX, mouseY)) {
                startLevel(currentLevel + 1);
            }
        }
        
        Button levelsBtn = {SCREEN_W/2-70, 245, 140, 35, "LEVELS", COL_BLUE, COL_WHITE};
        Button menuBtn   = {SCREEN_W/2-70, 290, 140, 35, "MENU", COL_DGRAY, COL_WHITE};
        drawButton(renderer, levelsBtn, levelsBtn.contains(mouseX, mouseY));
        drawButton(renderer, menuBtn, menuBtn.contains(mouseX, mouseY));
        
        if (mouseClicked) {
            if (levelsBtn.contains(mouseX, mouseY)) state = STATE_LEVEL_SELECT;
            else if (menuBtn.contains(mouseX, mouseY)) state = STATE_MENU;
        }
    }
    
    // --------------------------------------------------------
    // MAIN LOOP
    // --------------------------------------------------------
    void run() {
        while (running) {
            Uint32 frameStart = SDL_GetTicks();
            tick++;
            mouseClicked = false;
            
            // Events
            SDL_Event e;
            while (SDL_PollEvent(&e)) {
                if (e.type == SDL_QUIT) running = false;
                else if (e.type == SDL_MOUSEMOTION) {
                    mouseX = e.motion.x;
                    mouseY = e.motion.y;
                }
                else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
                    mouseDown = true;
                    mouseClicked = true;
                }
                else if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
                    mouseDown = false;
                }
                else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_RIGHT) {
                    // Cancel selection
                    selectedPlant = PLANT_NONE;
                    selectedSlot = -1;
                    shovelMode = false;
                }
                else if (e.type == SDL_KEYDOWN) {
                    if (e.key.keysym.sym == SDLK_ESCAPE) {
                        if (state == STATE_PLAYING) state = STATE_PAUSED;
                        else if (state == STATE_PAUSED) state = STATE_PLAYING;
                        else if (state == STATE_ALMANAC) state = STATE_MENU;
                        else if (state == STATE_LEVEL_SELECT) state = STATE_MENU;
                    }
                    // Debug: press 'S' to add sun
                    #ifdef DEBUG
                    if (e.key.keysym.sym == SDLK_s && state == STATE_PLAYING) sunCount += 100;
                    if (e.key.keysym.sym == SDLK_u && state == STATE_PLAYING) highestLevel = MAX_LEVELS - 1;
                    #endif
                }
            }
            
            // Clear
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderClear(renderer);
            
            // State machine
            switch (state) {
                case STATE_MENU:
                    drawMenu();
                    break;
                case STATE_LEVEL_SELECT:
                    drawLevelSelect();
                    break;
                case STATE_PLAYING:
                    handleGameInput();
                    updateGame();
                    drawGame();
                    break;
                case STATE_PAUSED:
                    drawPaused();
                    break;
                case STATE_GAME_OVER:
                    drawGameOver();
                    break;
                case STATE_LEVEL_COMPLETE:
                    drawLevelComplete();
                    break;
                case STATE_ALMANAC:
                    drawAlmanac();
                    break;
            }
            
            SDL_RenderPresent(renderer);
            
            // Frame cap
            Uint32 frameTime = SDL_GetTicks() - frameStart;
            if (frameTime < FRAME_DELAY) SDL_Delay(FRAME_DELAY - frameTime);
        }
    }
};

// ============================================================
// MAIN
// ============================================================
int main(int argc, char* argv[]) {
    (void)argc; (void)argv;
    
    Game game;
    if (!game.init()) {
        printf("Failed to initialize!\n");
        return 1;
    }
    
    game.run();
    game.cleanup();
    return 0;
}
